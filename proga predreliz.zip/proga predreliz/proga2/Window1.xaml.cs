﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using Renci.SshNet;
using System.Threading;

namespace proga2
{
    /// <summary>
    /// Логика взаимодействия для Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        public Window1()
        {
            InitializeComponent();
            listboxitem.ItemsSource = pcSrvList;
            LoadPcSrvList();
        }
        private string DataFilePath = "pcsrvlist.json";
        private ObservableCollection<PCSRV> pcSrvList = new ObservableCollection<PCSRV>();
        private List<string> listString = new List<string>();
        private string intint = "";
        private bool nogood = true;
        private string ospfProcessId = "";
        private string bgpAsNumber = "";
        private string greTunnelNumber = "";
        private void ButtonStart_Click(object sender, RoutedEventArgs e)
        {
            inter.Content = "Получение конфига";
            progress.IsIndeterminate = true;
            RichTextBoxOutput.AppendText($"\nИнформация о всех интерфейсах\r");
            LoadPcSrvList();
            if (nogood)
            {
                combo.Items.Clear();
            }
            var iptext = this.IP.Text;
            var logintext = this.Login.Text;
            var passwordtext = this.Password.Text;
            listString.Clear();
            // MessageBox.Show(iptext);
            // MessageBox.Show(logintext);
            // MessageBox.Show(passwordtext);
            // RichTextBoxOutput.AppendText($"IP address: {iptext}, \nLogin: {logintext}, \nPassword: {passwordtext}");
            Task.Run(() =>
            {
                var connect = new SshClient(iptext, 22, logintext, passwordtext);
                connect.Connect();
                var shell = connect.CreateShellStream("terminal", 80, 24, 800, 600, 1024);
                shell.WriteLine("terminal length 0\n show run\n exit\n");

                Thread.Sleep(200);
                while (true)
                {
                    if (!shell.CanRead || shell.DataAvailable == false) break;
                    if (shell.Length <= 30) break;

                    var line = shell.ReadLine() ?? "null a shell";
                    listString.Add(line);
                    Thread.Sleep(20);
                }
                shell.Dispose();
                connect.Disconnect();
                bool good = false;
                Dispatcher.Invoke(() =>
                {
                    foreach (var line in listString)
                    {
                        if (good && !line.Contains("#") && !string.IsNullOrEmpty(line))
                        {
                            if (line.Length > 4)
                            {
                                RichTextBoxOutput.AppendText($"{line}\r");

                            }
                        }
                        if (line.Contains("interface"))
                        {
                            RichTextBoxOutput.AppendText($"{line}\r");
                            good = true;
                            if (nogood)
                            {
                                combo.Items.Add(line);
                            }
                        }
                        else
                        {
                            good = false;
                        }
                    }
                    nogood = false;
                    progress.IsIndeterminate = false;
                    inter.Content = "Конфиг получен";
                });
            });

        }

        private void list_select(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            if (listboxitem.SelectedItem is PCSRV selectedPcSrv)
            {
                IP.Text = selectedPcSrv.IpAddress;
                Login.Text = selectedPcSrv.Username;
                Password.Text = selectedPcSrv.Password;
            }
        }
        private void Buttonip_Click(object sender, RoutedEventArgs e)
        {
            string changeip = this.IPvvod.Text;
            string changemask = this.Maskvvod.Text;
            string changeinter = intint;
            var iptext = this.IP.Text;
            var logintext = this.Login.Text;
            var passwordtext = this.Password.Text;
            inter.Content = "Изменение IP";
            progress.IsIndeterminate = true;
            Task.Run(() =>
            {
                var connect = new SshClient(iptext, 22, logintext, passwordtext);
                connect.Connect();
                var shell = connect.CreateShellStream("terminal", 80, 24, 800, 600, 1024);
                shell.WriteLine($"terminal length 0\n conf t\n {changeinter}\n ip add {changeip} {changemask}\n");

                Dispatcher.Invoke(() =>
                {
                    inter.Content = "Дождитесь обновления данных";
                });
                shell.WriteLine("terminal length 0\n do show run\n exit\n");

                Thread.Sleep(200);
                while (true)
                {
                    if (!shell.CanRead || shell.DataAvailable == false) break;
                    if (shell.Length <= 30) break;

                    var line = shell.ReadLine() ?? "null a shell";
                    listString.Add(line);
                    Thread.Sleep(20);
                }
                shell.Dispose();
                connect.Disconnect();
                Dispatcher.Invoke(() =>
                {
                    inter.Content = "IP обновлён";
                    progress.IsIndeterminate = false;
                });
            });
            RichTextBoxOutput.AppendText($"\nIP изменён на {changeip} {changemask}\nНажмите Start для отображения нового IP\r");
        }
        public void LoadPcSrvList()
        {
            if (File.Exists(DataFilePath))
            {
                var jsonData = File.ReadAllText(DataFilePath);
                var loadedPcSrvList = JsonConvert.DeserializeObject<ObservableCollection<PCSRV>>(jsonData) ?? new ObservableCollection<PCSRV>();

                pcSrvList.Clear();
                foreach (var pcSrv in loadedPcSrvList)
                {
                    pcSrvList.Add(pcSrv);
                }
            }
        }

        private void combo_select(object sender, SelectionChangedEventArgs e)
        {
            {
                var info = this.combo.SelectedItem.ToString();
                RichTextBoxOutput.AppendText($"\nВыбран интерфейс {info}\r");
                inter.Content = info;
                intint = info;
                bool good = false;
                foreach (var line in listString)
                {
                    if (good && !line.Contains("#") && !string.IsNullOrEmpty(line))
                    {
                        if (line.Length > 4)
                        {
                            string ipinfo = ($"{line}\r");
                            if (ipinfo.Contains("no"))
                            {
                                IPvvod.Clear();
                                Maskvvod.Clear();
                                IPvvod.AppendText("no ip");
                                Maskvvod.AppendText("no mask");
                            }
                            else
                            {
                                string[] listinfo = ipinfo.Split(' ');
                                IPvvod.Clear();
                                Maskvvod.Clear();
                                IPvvod.AppendText(listinfo[3]);
                                Maskvvod.AppendText(listinfo[4]);
                            }

                        }
                    }
                    if (line.Contains(info))
                    {
                        good = true;
                    }
                    else
                    {
                        good = false;
                    }

                }
            }
        }

        private void ButtonBack_Click(object sender, RoutedEventArgs e)
        {
            MainWindow taskWindow = new MainWindow();
            taskWindow.Show();
            this.Close();
        }
        private void ButtonConfigureOSPF_Click(object sender, RoutedEventArgs e)
        {
            var processId = this.OSPFProcessId.Text;
            var networkAddress = this.OSPFNetwork.Text;
            var wildcard = this.OSPFWildcard.Text;
            var area = this.OSPFArea.Text;

            var iptext = this.IP.Text;
            var logintext = this.Login.Text;
            var passwordtext = this.Password.Text;

            inter.Content = "Настройка OSPF";
            progress.IsIndeterminate = true;

            Task.Run(() =>
            {
                var connect = new SshClient(iptext, 22, logintext, passwordtext);
                connect.Connect();
                var shell = connect.CreateShellStream("terminal", 80, 24, 800, 600, 1024);

                shell.WriteLine($"conf t\n router ospf {processId}\n network {networkAddress} {wildcard} area {area}\n end\n");
                Thread.Sleep(200);

                shell.WriteLine("show ip ospf\n");
                while (shell.DataAvailable)
                {
                    var line = shell.ReadLine();
                    if (!string.IsNullOrEmpty(line))
                    {
                        Dispatcher.Invoke(() =>
                        {
                            RichTextBoxOutput.AppendText($"{line}\r");
                        });
                    }
                }

                shell.Dispose();
                connect.Disconnect();

                Dispatcher.Invoke(() =>
                {
                    inter.Content = "OSPF настроен";
                    progress.IsIndeterminate = false;
                    RichTextBoxOutput.AppendText($"\nOSPF процесс {processId} настроен\r");
                });
            });
        }
        private void ButtonConfigureBGP_Click(object sender, RoutedEventArgs e)
        {
            var asNumber = this.BGPAsNumber.Text;
            var neighborIp = this.BGPNeighborIP.Text;
            var neighborAs = this.BGPNeighborAS.Text;

            var iptext = this.IP.Text;
            var logintext = this.Login.Text;
            var passwordtext = this.Password.Text;

            inter.Content = "Настройка BGP";
            progress.IsIndeterminate = true;

            Task.Run(() =>
            {
                var connect = new SshClient(iptext, 22, logintext, passwordtext);
                connect.Connect();
                var shell = connect.CreateShellStream("terminal", 80, 24, 800, 600, 1024);

                shell.WriteLine($"conf t\n router bgp {asNumber}\n neighbor {neighborIp} remote-as {neighborAs}\n end\n");
                Thread.Sleep(200);

                shell.WriteLine("show ip bgp summary\n");
                while (shell.DataAvailable)
                {
                    var line = shell.ReadLine();
                    if (!string.IsNullOrEmpty(line))
                    {
                        Dispatcher.Invoke(() =>
                        {
                            RichTextBoxOutput.AppendText($"{line}\r");
                        });
                    }
                }

                shell.Dispose();
                connect.Disconnect();

                Dispatcher.Invoke(() =>
                {
                    inter.Content = "BGP настроен";
                    progress.IsIndeterminate = false;
                    RichTextBoxOutput.AppendText($"\nBGP процесс AS{asNumber} настроен\r");
                });
            });
        }
        private void ButtonConfigureGRE_Click(object sender, RoutedEventArgs e)
        {
            var tunnelNumber = this.GRETunnelNumber.Text;
            var sourceIp = this.GRESourceIP.Text;
            var destinationIp = this.GREDestinationIP.Text;
            var tunnelIp = this.GRETunnelIP.Text;
            var tunnelMask = this.GRETunnelMask.Text;

            var iptext = this.IP.Text;
            var logintext = this.Login.Text;
            var passwordtext = this.Password.Text;

            inter.Content = "Настройка GRE туннеля";
            progress.IsIndeterminate = true;

            Task.Run(() =>
            {
                var connect = new SshClient(iptext, 22, logintext, passwordtext);
                connect.Connect();
                var shell = connect.CreateShellStream("terminal", 80, 24, 800, 600, 1024);

                shell.WriteLine($"conf t\n interface tunnel {tunnelNumber}\n" +
                              $"ip address {tunnelIp} {tunnelMask}\n" +
                              $"tunnel source {sourceIp}\n" +
                              $"tunnel destination {destinationIp}\n" +
                              $"tunnel mode gre ip\n end\n");
                Thread.Sleep(200);

                shell.WriteLine($"show interfaces tunnel {tunnelNumber}\n");
                while (shell.DataAvailable)
                {
                    var line = shell.ReadLine();
                    if (!string.IsNullOrEmpty(line))
                    {
                        Dispatcher.Invoke(() =>
                        {
                            RichTextBoxOutput.AppendText($"{line}\r");
                        });
                    }
                }

                shell.Dispose();
                connect.Disconnect();

                Dispatcher.Invoke(() =>
                {
                    inter.Content = "GRE туннель настроен";
                    progress.IsIndeterminate = false;
                    RichTextBoxOutput.AppendText($"\nGRE туннель {tunnelNumber} настроен\r");
                });
            });
        }

        private void ButtonShowRouting_Click(object sender, RoutedEventArgs e)
        {
            var iptext = this.IP.Text;
            var logintext = this.Login.Text;
            var passwordtext = this.Password.Text;

            inter.Content = "Получение информации о маршрутизации";
            progress.IsIndeterminate = true;

            Task.Run(() =>
            {
                var connect = new SshClient(iptext, 22, logintext, passwordtext);
                connect.Connect();
                var shell = connect.CreateShellStream("terminal", 80, 24, 800, 600, 1024);

                shell.WriteLine("terminal length 0\n");
                shell.WriteLine("show ip route\n");
                shell.WriteLine("show ip ospf neighbor\n");
                shell.WriteLine("show ip bgp\n");
                shell.WriteLine("show interfaces tunnel\n");

                Thread.Sleep(200);
                while (shell.DataAvailable)
                {
                    var line = shell.ReadLine();
                    if (!string.IsNullOrEmpty(line))
                    {
                        Dispatcher.Invoke(() =>
                        {
                            RichTextBoxOutput.AppendText($"{line}\r");
                        });
                    }
                }

                shell.Dispose();
                connect.Disconnect();

                Dispatcher.Invoke(() =>
                {
                    inter.Content = "Информация получена";
                    progress.IsIndeterminate = false;
                });
            });
        }
    }
}
