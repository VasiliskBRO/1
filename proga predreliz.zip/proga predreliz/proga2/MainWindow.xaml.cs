﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net.NetworkInformation;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using Newtonsoft.Json;
using proga2;
using Renci.SshNet;

namespace proga2
{
    public partial class MainWindow : Window
    {
        private const string DataFilePath = "pcsrvlist.json";
        private ObservableCollection<PCSRV> pcSrvList = new ObservableCollection<PCSRV>();

        public MainWindow()
        {
            InitializeComponent();
            listbox.ItemsSource = pcSrvList;
            LoadPcSrvList();
        }
        private void ButtonNew_Click(object sender, RoutedEventArgs e)
        {
            Window2 taskWindow = new Window2();
            taskWindow.Show();
            this.Close();

        }
        //public void ButtonAdd_Clickk()
        //{
        //    string Namen = this.Namebox.Text;
        //    if (pcSrvList.Any(p => p.Hostname == Namen))
        //    {
        //        MessageBox.Show("Такое имя уже существует");
        //        return;
        //    } 

        //    string Passp = this.Passwordbox.Text;
        //    string IPIP = this.IPbox.Text;
        //    string Logl = this.Loginbox.Text;
        //    var newPcSrv = new PCSRV
        //    {
        //        Hostname = Namen,
        //        IpAddress = IPIP,
        //        Username = Logl,
        //        Password = Passp
        //    };

        //    pcSrvList.Add(newPcSrv);
        //    SavePcSrvList();
        //}
        private void ButtonDel_Click(object sender, RoutedEventArgs e)
        {
            if (listbox.SelectedItem is PCSRV selectedPcSrv)
            {
                pcSrvList.Remove(selectedPcSrv);
                SavePcSrvList();
            }
            else
            {
                MessageBox.Show("Выберите устройство для удаления");
            }
        }

        private void PCSRV_Select(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            if (listbox.SelectedItem is PCSRV selectedPcSrv)
            {
                Namebox.Text = selectedPcSrv.Hostname;
                IPbox.Text = selectedPcSrv.IpAddress;
                Loginbox.Text = selectedPcSrv.Username;
                Passwordbox.Text = selectedPcSrv.Password;
            }
        }

        private void ButtonStart_Click(object sender, RoutedEventArgs e)
        {
            string Namen = this.Namebox.Text;
            try
            {
                Process.Start("C:\\Program Files\\WindowsApps\\Microsoft.MicrosoftSolitaireCollection_4.20.8090.0_x64__8wekyb3d8bbwe\\Solitaire.exe");
            }
            catch
            {
                MessageBox.Show($"Произошла ошибка");
            }
        }

        public void LoadPcSrvList()
        {
            if (File.Exists(DataFilePath))
            {
                var jsonData = File.ReadAllText(DataFilePath);
                var loadedPcSrvList = JsonConvert.DeserializeObject<ObservableCollection<PCSRV>>(jsonData) ?? new ObservableCollection<PCSRV>();

                pcSrvList.Clear();
                foreach (var pcSrv in loadedPcSrvList)
                {
                    pcSrvList.Add(pcSrv);
                }
            }
        }

        public void SavePcSrvList()
        {
            var jsonData = JsonConvert.SerializeObject(pcSrvList, Formatting.Indented);
            File.WriteAllText(DataFilePath, jsonData);
        }

        private void ButtonSsh_Click(object sender, RoutedEventArgs e)
        {
            Window1 taskWindow1 = new Window1();
            taskWindow1.Show();
            this.Close();
        }
        private async void ButtonPing_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(IPbox.Text))
            {
                PingStatus.Text = "Please enter an IP address";
                PingStatus.Foreground = Brushes.Yellow;
                MessageBox.Show("Введите IP адрес!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                using (Ping ping = new Ping())
                {
                    PingStatus.Text = "Pinging...";
                    PingStatus.Foreground = Brushes.White;

                    var reply = await Task.Run(() => ping.Send(IPbox.Text, 1000));

                    if (reply.Status == IPStatus.Success)
                    {
                        PingStatus.Text = $"Device is reachable (Response time: {reply.RoundtripTime}ms)";
                        PingStatus.Foreground = Brushes.LightGreen;
                    }
                    else
                    {
                        PingStatus.Text = "Device is not responding";
                        PingStatus.Foreground = Brushes.OrangeRed;
                        MessageBox.Show("Устройство не отвечает!", "Ошибка соединения", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            }
            catch (PingException)
            {
                PingStatus.Text = "Unable to ping this address";
                PingStatus.Foreground = Brushes.Red;
                MessageBox.Show("Невозможно выполнить пинг по этому адресу!", "Ошибка пинга", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }

    public enum DeviceType
    {
        Cisco,
        MikroTik,
        Linux,
        Windows
    }

    public class PCSRV
    {

        // Свойства с использованием современного синтаксиса C#
        public string Hostname { get; set; }
        public string IpAddress { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public DeviceType Type { get; set; }

        // Переопределение ToString для корректного отображения в ListBox
        public override string ToString()
        {
            return $"{Hostname} ({Type}) - {IpAddress}";
        }
    }
}
