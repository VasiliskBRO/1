﻿using Newtonsoft.Json;
using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Xml.Linq;
namespace proga2
{
    /// <summary>
    /// Логика взаимодействия для Window2.xaml
    /// </summary>
    public partial class Window2 : Window
    {
        private const string DataFilePath = "pcsrvlist.json";
        private ObservableCollection<PCSRV> pcSrvList = new ObservableCollection<PCSRV>();
        public Window2()
        {
            MainWindow taskWindow = new MainWindow();
            InitializeComponent();
            LoadPcSrvList();
        }

        private bool IsValidIPAddress(string ipAddress)
        {
            // Проверка на пустую строку
            if (string.IsNullOrWhiteSpace(ipAddress))
            {
                MessageBox.Show("IP-адрес не может быть пустым или содержать только пробелы. Пожалуйста, введите корректный IP-адрес (например, 192.168.1.1)", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }
            // Проверка формата через регулярное выражение
            string pattern = @"^((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$";
            if (!Regex.IsMatch(ipAddress, pattern))
            {
                MessageBox.Show("Неверный формат IP-адреса. Пожалуйста, введите корректный IP-адрес (например, 192.168.1.1)", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }
            // Дополнительная проверка через IPAddress.TryParse
            if (!IPAddress.TryParse(ipAddress, out _))
            {
                MessageBox.Show("IP-адрес недействителен. Пожалуйста, введите корректный IP-адрес (например, 192.168.1.1)", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }
            return true;
        }

        private void ButtonAdd_Click(object sender, RoutedEventArgs e)
        {
            // Если добавление прошло успешно, только тогда переходим в главное окно
            if (Add())
            {
                try
                {
                    MainWindow taskWindow = new MainWindow();
                    taskWindow.Show();
                    this.Close();
                }
                catch (Exception)
                {

                }
            }
        }

        private void ButtonAddAdd_Click(object sender, RoutedEventArgs e)
        {
            if (Add())
            {
                try
                {
                    Namebox.Text = "";
                    IPbox.Text = "";
                    Loginbox.Text = "";
                    Passwordbox.Text = "";
                }
                catch (Exception)
                {

                }
            }
        }

        private bool Add()
        {
            string Namen = this.Namebox.Text;
            if (pcSrvList.Any(p => p.Hostname == Namen))
            {
                MessageBox.Show("Такое имя уже существует", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }

            string IPIP = this.IPbox.Text;
            if (!IsValidIPAddress(IPIP))
            {
                return false;
            }

            string Logl = this.Loginbox.Text;
            string Passp = this.Passwordbox.Text;

            var newPcSrv = new PCSRV
            {
                Hostname = Namen,
                IpAddress = IPIP,
                Username = Logl,
                Password = Passp,
            };

            pcSrvList.Add(newPcSrv);
            SavePcSrvList();
            MessageBox.Show($"Устройство {Namebox.Text} добавлено", "Успешно", MessageBoxButton.OK, MessageBoxImage.Information);
            return true;
        }


        public void LoadPcSrvList()
        {
            if (File.Exists(DataFilePath))
            {
                var jsonData = File.ReadAllText(DataFilePath);
                var loadedPcSrvList = JsonConvert.DeserializeObject<ObservableCollection<PCSRV>>(jsonData) ?? new ObservableCollection<PCSRV>();

                pcSrvList.Clear();
                foreach (var pcSrv in loadedPcSrvList)
                {
                    pcSrvList.Add(pcSrv);
                }
            }
        }
        public void SavePcSrvList()
        {
            var jsonData = JsonConvert.SerializeObject(pcSrvList, Formatting.Indented);
            File.WriteAllText(DataFilePath, jsonData);
        }

        private void ButtonBack_Click(object sender, RoutedEventArgs e)
        {
            MainWindow taskWindow = new MainWindow();
            taskWindow.Show();
            this.Close();
        }
    }
}
