﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using Renci.SshNet;
using System.Threading;

namespace proga2
{
    /// <summary>
    /// Логика взаимодействия для Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        public Window1()
        {
            InitializeComponent();
            listboxitem.ItemsSource = pcSrvList;
            LoadPcSrvList();
        }
        private string DataFilePath = "pcsrvlist.json";
        private ObservableCollection<PCSRV> pcSrvList = new ObservableCollection<PCSRV>();
        private List<string> listString = new List<string>();
        private string intint = "";
        private bool nogood = true;
        private void ButtonStart_Click(object sender, RoutedEventArgs e)
        {
            inter.Content = "Получение конфига";
            progress.IsIndeterminate = true;
            RichTextBoxOutput.AppendText($"\nИнформация о всех интерфейсах\r");
            LoadPcSrvList();
            if (nogood)
            {
                combo.Items.Clear();
            }
            var iptext = this.IP.Text;
            var logintext = this.Login.Text;
            var passwordtext = this.Password.Text;
            listString.Clear();
            // MessageBox.Show(iptext);
            // MessageBox.Show(logintext);
            // MessageBox.Show(passwordtext);
            // RichTextBoxOutput.AppendText($"IP address: {iptext}, \nLogin: {logintext}, \nPassword: {passwordtext}");
            Task.Run(() =>
            {
                var connect = new SshClient(iptext, 22, logintext, passwordtext);
                    connect.Connect();
                var shell = connect.CreateShellStream("terminal", 80, 24, 800, 600, 1024);
                shell.WriteLine("terminal length 0\n show run\n exit\n");

                Thread.Sleep(200);
                while (true)
                {
                    if (!shell.CanRead || shell.DataAvailable == false) break;
                    if (shell.Length <= 30) break;

                    var line = shell.ReadLine() ?? "null a shell";
                    listString.Add(line);
                    Thread.Sleep(20);
                }
                shell.Dispose();
                connect.Disconnect();
                bool good = false;
                Dispatcher.Invoke(() =>
                {
                    foreach (var line in listString)
                    {
                        if (good && !line.Contains("#") && !string.IsNullOrEmpty(line))
                        {
                            if (line.Length > 4)
                            {
                                RichTextBoxOutput.AppendText($"{line}\r");

                            }
                        }
                        if (line.Contains("interface"))
                        {
                            RichTextBoxOutput.AppendText($"{line}\r");
                            good = true;
                            if (nogood)
                            {
                                combo.Items.Add(line);
                            }
                        }
                        else
                        {
                            good = false;
                        }
                    }
                    nogood = false;
                    progress.IsIndeterminate = false;
                    inter.Content = "Конфиг получен";
                });
            });

        }

        private void list_select(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            if (listboxitem.SelectedItem is PCSRV selectedPcSrv)
            {
                IP.Text = selectedPcSrv.IpAddress;
                Login.Text = selectedPcSrv.Username;
                Password.Text = selectedPcSrv.Password;
            }
        }
        private void Buttonip_Click(object sender, RoutedEventArgs e)
        {
            string changeip = this.IPvvod.Text;
            string changemask = this.Maskvvod.Text;
            string changeinter = intint;
            var iptext = this.IP.Text;
            var logintext = this.Login.Text;
            var passwordtext = this.Password.Text;
            inter.Content = "Изменение IP";
            progress.IsIndeterminate = true;
            Task.Run(() =>
            {
                var connect = new SshClient(iptext, 22, logintext, passwordtext);
                connect.Connect();
                var shell = connect.CreateShellStream("terminal", 80, 24, 800, 600, 1024);
                shell.WriteLine($"terminal length 0\n conf t\n {changeinter}\n ip add {changeip} {changemask}\n");

                Dispatcher.Invoke(() =>
                {
                    inter.Content = "Дождитесь обновления данных";
                });
                shell.WriteLine("terminal length 0\n do show run\n exit\n");

                Thread.Sleep(200);
                while (true)
                {
                    if (!shell.CanRead || shell.DataAvailable == false) break;
                    if (shell.Length <= 30) break;

                    var line = shell.ReadLine() ?? "null a shell";
                    listString.Add(line);
                    Thread.Sleep(20);
                }
                shell.Dispose();
                connect.Disconnect();
                Dispatcher.Invoke(() =>
                {
                    inter.Content = "IP обновлён";
                    progress.IsIndeterminate = false;
                });
            });
            RichTextBoxOutput.AppendText($"\nIP изменён на {changeip} {changemask}\nНажмите Start для отображения нового IP\r");
        }
        public void LoadPcSrvList()
        {
            if (File.Exists(DataFilePath))
            {
                var jsonData = File.ReadAllText(DataFilePath);
                var loadedPcSrvList = JsonConvert.DeserializeObject<ObservableCollection<PCSRV>>(jsonData) ?? new ObservableCollection<PCSRV>();

                pcSrvList.Clear();
                foreach (var pcSrv in loadedPcSrvList)
                {
                    pcSrvList.Add(pcSrv);
                }
            }
        }

        private void combo_select(object sender, SelectionChangedEventArgs e)
        {
            {
                var info = this.combo.SelectedItem.ToString();
                RichTextBoxOutput.AppendText($"\nВыбран интерфейс {info}\r");
                inter.Content = info;
                intint = info;
                bool good = false;
                foreach (var line in listString)
                {
                    if (good && !line.Contains("#") && !string.IsNullOrEmpty(line))
                    {
                        if (line.Length > 4)
                        {
                            string ipinfo = ($"{line}\r");
                            if (ipinfo.Contains("no"))
                            {
                                IPvvod.Clear();
                                Maskvvod.Clear();
                                IPvvod.AppendText("no ip");
                                Maskvvod.AppendText("no mask");
                            }
                            else
                            {
                                string[] listinfo = ipinfo.Split(' ');
                                IPvvod.Clear();
                                Maskvvod.Clear();
                                IPvvod.AppendText(listinfo[3]);
                                Maskvvod.AppendText(listinfo[4]);
                            }

                        }
                    }
                    if (line.Contains(info))
                    {
                        good = true;
                    }
                    else
                    {
                        good = false;
                    }

                }
            }
        }

        private void ButtonBack_Click(object sender, RoutedEventArgs e)
        {
            MainWindow taskWindow = new MainWindow();
            taskWindow.Show();
            this.Close();
        }
    }
}
