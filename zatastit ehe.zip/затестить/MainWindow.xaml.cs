﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using Newtonsoft.Json;
using proga2;
using Renci.SshNet;

namespace proga2
{
    public partial class MainWindow : Window
    {
        private const string DataFilePath = "pcsrvlist.json";
        private ObservableCollection<PCSRV> pcSrvList = new ObservableCollection<PCSRV>();

        public MainWindow()
        {
            InitializeComponent();
            listbox.ItemsSource = pcSrvList;
            LoadPcSrvList();
        }
        private void ButtonNew_Click(object sender, RoutedEventArgs e)
        {
            Window2 taskWindow = new Window2();
            taskWindow.Show();
            this.Close();

        }
        //public void ButtonAdd_Clickk()
        //{
        //    string Namen = this.Namebox.Text;
        //    if (pcSrvList.Any(p => p.Hostname == Namen))
        //    {
        //        MessageBox.Show("Такое имя уже существует");
        //        return;
        //    } 

        //    string Passp = this.Passwordbox.Text;
        //    string IPIP = this.IPbox.Text;
        //    string Logl = this.Loginbox.Text;
        //    var newPcSrv = new PCSRV
        //    {
        //        Hostname = Namen,
        //        IpAddress = IPIP,
        //        Username = Logl,
        //        Password = Passp
        //    };

        //    pcSrvList.Add(newPcSrv);
        //    SavePcSrvList();
        //}
        private void ButtonDel_Click(object sender, RoutedEventArgs e)
        {
            if (listbox.SelectedItem is PCSRV selectedPcSrv)
            {
                pcSrvList.Remove(selectedPcSrv);
                SavePcSrvList();
            }
            else
            {
                MessageBox.Show("Выберите устройство для удаления");
            }
        }

        private void PCSRV_Select(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            if (listbox.SelectedItem is PCSRV selectedPcSrv)
            {
                Namebox.Text = selectedPcSrv.Hostname;
                IPbox.Text = selectedPcSrv.IpAddress;
                Loginbox.Text = selectedPcSrv.Username;
                Passwordbox.Text = selectedPcSrv.Password;
            }
        }

        private void ButtonStart_Click(object sender, RoutedEventArgs e)
        {
            string Namen = this.Namebox.Text;
            try
            {
                Process.Start("C:\\Program Files\\WindowsApps\\Microsoft.MicrosoftSolitaireCollection_4.20.8090.0_x64__8wekyb3d8bbwe\\Solitaire.exe");
            }
            catch
            {
                MessageBox.Show($"Произошла ошибка");
            }
        }

        public void LoadPcSrvList()
        {
            if (File.Exists(DataFilePath))
            {
                var jsonData = File.ReadAllText(DataFilePath);
                var loadedPcSrvList = JsonConvert.DeserializeObject<ObservableCollection<PCSRV>>(jsonData) ?? new ObservableCollection<PCSRV>();

                pcSrvList.Clear();
                foreach (var pcSrv in loadedPcSrvList)
                {
                    pcSrvList.Add(pcSrv);
                }
            }
        }

        public void SavePcSrvList()
        {
            var jsonData = JsonConvert.SerializeObject(pcSrvList, Formatting.Indented);
            File.WriteAllText(DataFilePath, jsonData);
        }

        private void ButtonSsh_Click(object sender, RoutedEventArgs e)
        {
            Window1 taskWindow1 = new Window1();
            taskWindow1.Show();
            this.Close();
        }
    }

    public class PCSRV
    {
        private string hostname;
        private string ipAddress;
        private string username;
        private string password;

        public string Hostname
        {
            get => hostname;
            set
            {
                hostname = value;
            }
        }

        public string IpAddress
        {
            get => ipAddress;
            set
            {
                ipAddress = value;
            }
        }

        public string Username
        {
            get => username;
            set
            {
                username = value;
            }
        }

        public string Password
        {
            get => password;
            set
            {
                password = value;
            }
        }
        private async void ButtonPing_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(IPbox.Text))
            {
                PingStatus.Text = "Please enter an IP address";
                PingStatus.Foreground = Brushes.Yellow;
                return;
            }

            try
            {
                using (Ping ping = new Ping())
                {
                    PingStatus.Text = "Pinging...";
                    PingStatus.Foreground = Brushes.White;

                    var reply = await Task.Run(() => ping.Send(IPbox.Text, 1000));

                    if (reply.Status == IPStatus.Success)
                    {
                        PingStatus.Text = $"Device is reachable (Response time: {reply.RoundtripTime}ms)";
                        PingStatus.Foreground = Brushes.LightGreen;
                    }
                    else
                    {
                        PingStatus.Text = "Device is not responding";
                        PingStatus.Foreground = Brushes.OrangeRed;
                    }
                }
            }
            catch (PingException)
            {
                PingStatus.Text = "Unable to ping this address";
                PingStatus.Foreground = Brushes.Red;
            }
        }
    }
}
