﻿using Newtonsoft.Json;
using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Xml.Linq;
namespace proga2
{
    /// <summary>
    /// Логика взаимодействия для Window2.xaml
    /// </summary>
    public partial class Window2 : Window
    {
        private const string DataFilePath = "pcsrvlist.json";
        private ObservableCollection<PCSRV> pcSrvList = new ObservableCollection<PCSRV>();
        public Window2()
        {
            MainWindow taskWindow = new MainWindow();
            InitializeComponent();
            LoadPcSrvList();
        }

        private void ButtonAdd_Click(object sender, RoutedEventArgs e)
        {
            Add();
            MainWindow taskWindow = new MainWindow();
            taskWindow.Show();
            this.Close();
        }
        private void ButtonAddAdd_Click(object sender, RoutedEventArgs e)
        {
            Add();
            Namebox.Text = "";
            IPbox.Text = "";
            Loginbox.Text = "";
            Passwordbox.Text = "";

        }
        private void Add()
        {
            string Namen = this.Namebox.Text;
            if (pcSrvList.Any(p => p.Hostname == Namen))
            {
                MessageBox.Show("Такое имя уже существует");
                return;
            }

            if (DeviceTypeBox.SelectedItem == null)
            {
                MessageBox.Show("Выберите тип устройства");
                return;
            }

            string deviceTypeStr = ((ComboBoxItem)DeviceTypeBox.SelectedItem).Content.ToString();
            // Преобразуем строку в enum
            DeviceType deviceType;
            if (!Enum.TryParse(deviceTypeStr, out deviceType))
            {
                MessageBox.Show("Неверный тип устройства");
                return;
            }

            string Passp = this.Passwordbox.Text;
            string IPIP = this.IPbox.Text;
            string Logl = this.Loginbox.Text;

            var newPcSrv = new PCSRV
            {
                Hostname = Namen,
                IpAddress = IPIP,
                Username = Logl,
                Password = Passp,
                Type = deviceType // Используем Type вместо DeviceType, так как это имя свойства в классе
            };

            pcSrvList.Add(newPcSrv);
            SavePcSrvList();
            MessageBox.Show($"Устройство {Namebox.Text} ({deviceType}) добавлено");
        }
        public void LoadPcSrvList()
        {
            if (File.Exists(DataFilePath))
            {
                var jsonData = File.ReadAllText(DataFilePath);
                var loadedPcSrvList = JsonConvert.DeserializeObject<ObservableCollection<PCSRV>>(jsonData) ?? new ObservableCollection<PCSRV>();

                pcSrvList.Clear();
                foreach (var pcSrv in loadedPcSrvList)
                {
                    pcSrvList.Add(pcSrv);
                }
            }
        }
        public void SavePcSrvList()
        {
            var jsonData = JsonConvert.SerializeObject(pcSrvList, Formatting.Indented);
            File.WriteAllText(DataFilePath, jsonData);
        }

        private void ButtonBack_Click(object sender, RoutedEventArgs e)
        {
            MainWindow taskWindow = new MainWindow();
            taskWindow.Show();
            this.Close();
        }
    }
}
